# Overview

LapaBus is a comprehensive Progressive Web App (PWA) for bus schedule management and commercial directory services in the São José da Lapa region and northern metropolitan area of Belo Horizonte, Brazil. The application provides offline-capable bus schedule lookup, real-time updates, and a complete business directory for local cities. Built as a modern web application with PWA capabilities, it serves as both a transportation guide and commercial directory for the region.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with **React 18** using **Vite** as the build tool for fast development and optimized production builds. The application follows a component-based architecture with modular, reusable components organized by feature areas (bus, maps, layout, UI).

**UI Framework**: Uses **shadcn/ui** component library built on top of **Radix UI** primitives, providing accessible and customizable components. The design system is implemented with **Tailwind CSS** with custom CSS variables for theming and Material Design-inspired elevation effects.

**State Management**: Utilizes **TanStack Query (React Query)** for server state management, caching, and synchronization. Local state is managed through React hooks and context where appropriate. Favorites and settings are persisted to localStorage.

**Routing**: Implements client-side routing with **Wouter**, a lightweight alternative to React Router, supporting the main navigation structure (Home, Lines, Cities, Map, Settings).

**PWA Implementation**: Full Progressive Web App capabilities including:
- Service worker for offline functionality and aggressive caching
- Web app manifest for installability
- Responsive design optimized for mobile devices
- Touch-friendly interactions and Material Design principles
- Install prompt component for encouraging app installation

## Backend Architecture
The backend follows a **REST API** architecture built with **Express.js** and **TypeScript**. The server provides JSON endpoints for bus lines, schedules, live updates, city data, and business directory information.

**API Structure**: RESTful endpoints including:
- `/api/lines` - Bus line management and search
- `/api/cities` - City information and business listings
- `/api/live-updates` - Real-time service announcements
- `/api/regions` - City region information
- `/api/favorites` - User favorite lines management

**Data Storage**: Currently uses in-memory storage implementations (`MemStorage`, `MemBusinessStorage`, `MemCitiesStorage`) that simulate database operations. The system is designed with interfaces to easily swap to a PostgreSQL database implementation when needed.

**Development Setup**: Vite middleware integration allows for hot module replacement during development, with production builds serving static assets through Express.

## Data Management
**Schema Definition**: Shared TypeScript schemas using **Drizzle ORM** and **Zod** for validation, ensuring type safety across the entire application stack. Schemas are defined for bus lines, schedules, cities, businesses, and user data.

**Caching Strategy**: Multi-layered caching approach:
- Service worker caches static assets and API responses with cache-first strategy
- React Query handles client-side data caching with automatic invalidation
- localStorage fallback for critical data when offline

**Real-time Integration**: Service architecture supports integration with external bus APIs for live schedule data and bus positioning, with fallback to local stored schedules.

## Progressive Web App Features
**Offline Capability**: Cache-first strategy where the service worker serves cached content when available, falling back to network requests. Critical schedule data is persisted locally for offline access.

**Installability**: Full PWA manifest with proper icons, screenshots, and metadata. Custom install prompt component that respects user preferences and dismissal state.

**Mobile Optimization**: Touch-friendly interface with proper safe area handling, Material Design elevation effects, and responsive design patterns optimized for mobile devices.

# External Dependencies

- **@neondatabase/serverless**: PostgreSQL database driver for external database connectivity
- **Drizzle ORM**: Type-safe database operations and schema management
- **Radix UI**: Accessible component primitives for the UI library
- **TanStack Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Vite**: Build tool and development server
- **shadcn/ui**: Component library built on Radix UI primitives
- **Lucide React**: Icon library for consistent iconography

The application is designed to work with external PostgreSQL databases (Supabase, Neon, Railway, Render) and includes configuration for real-time bus data integration with services like OpenBHBus API.