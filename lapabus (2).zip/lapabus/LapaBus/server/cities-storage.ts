import type { City, InsertCity, Business, InsertBusiness, CityWithBusinesses, BusinessCategory, InsertBusinessCategory } from "@shared/schema";
import { randomUUID } from "crypto";

export interface ICitiesStorage {
  // Cities
  getCities(): Promise<City[]>;
  getCity(slug: string): Promise<City | undefined>;
  getCityWithBusinesses(slug: string): Promise<CityWithBusinesses | undefined>;
  createCity(city: InsertCity): Promise<City>;
  
  // Businesses
  getBusinesses(): Promise<Business[]>;
  getBusinessesByCity(cityId: string): Promise<Business[]>;
  getBusinessesByCategory(category: string): Promise<Business[]>;
  getBusinessesByCityAndCategory(cityId: string, category: string): Promise<Business[]>;
  getBusiness(id: string): Promise<Business | undefined>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  searchBusinesses(query: string, cityId?: string): Promise<Business[]>;
  
  // Business Categories
  getBusinessCategories(): Promise<BusinessCategory[]>;
  getBusinessCategory(slug: string): Promise<BusinessCategory | undefined>;
  createBusinessCategory(category: InsertBusinessCategory): Promise<BusinessCategory>;
  
  // Legacy methods for compatibility
  getCityWithCompanies(slug: string): Promise<CityWithBusinesses | undefined>;
  getTransportCompanies(): Promise<Business[]>;
  getTransportCompaniesByCity(cityId: string): Promise<Business[]>;
  getTransportCompany(id: string): Promise<Business | undefined>;
  createTransportCompany(company: InsertBusiness): Promise<Business>;
}

export class MemCitiesStorage implements ICitiesStorage {
  private cities: Map<string, City> = new Map();
  private businesses: Map<string, Business> = new Map();
  private businessCategories: Map<string, BusinessCategory> = new Map();

  constructor() {
    this.initializeCategories();
    this.initializeData();
  }

  private initializeData() {
    // Initialize cities in BH Norte region
    const citiesData: InsertCity[] = [
      {
        name: "São José da Lapa",
        slug: "sao-jose-da-lapa",
        state: "MG",
        population: 21000,
        distanceFromBH: 32,
        description: "Município industrial da região metropolitana de BH, conhecido por suas indústrias e proximidade com o aeroporto.",
        banner: "/banners/sao-jose-lapa.jpg",
        coordinates: "-19.7850,-44.1450",
        isActive: true,
      },
      {
        name: "Vespasiano",
        slug: "vespasiano",
        state: "MG", 
        population: 135000,
        distanceFromBH: 25,
        description: "Cidade em franco crescimento, com diversos bairros residenciais e boa infraestrutura de transporte.",
        banner: "/banners/vespasiano.jpg",
        coordinates: "-19.6920,-44.0080",
        isActive: true,
      },
      {
        name: "Pedro Leopoldo",
        slug: "pedro-leopoldo",
        state: "MG",
        population: 65000,
        distanceFromBH: 40,
        description: "Cidade histórica conhecida pelo sítio arqueológico de Luzia e pela tradicional Festa de Reis.",
        banner: "/banners/pedro-leopoldo.jpg",
        coordinates: "-19.6180,-44.0420",
        isActive: true,
      },
      {
        name: "Lagoa Santa",
        slug: "lagoa-santa",
        state: "MG",
        population: 70000,
        distanceFromBH: 35,
        description: "Famosa por suas lagoas naturais e sítios arqueológicos, destino turístico da região metropolitana.",
        banner: "/banners/lagoa-santa.jpg",
        coordinates: "-19.6350,-43.8920",
        isActive: true,
      },
      {
        name: "Ribeirao das Neves",
        slug: "ribeirao-das-neves",
        state: "MG",
        population: 350000,
        distanceFromBH: 28,
        description: "Uma das maiores cidades da região metropolitana, com grande população e diversas linhas de transporte.",
        banner: "/banners/ribeirao-neves.jpg",
        coordinates: "-19.7670,-44.0870",
        isActive: true,
      },
      {
        name: "Confins",
        slug: "confins",
        state: "MG",
        population: 8000,
        distanceFromBH: 38,
        description: "Pequena cidade que abriga o Aeroporto Internacional Tancredo Neves, principal porta de entrada aérea de MG.",
        banner: "/banners/confins.jpg",
        coordinates: "-19.6320,-43.9730",
        isActive: true,
      }
    ];

    // Create cities
    citiesData.forEach(cityData => {
      const city: City = {
        id: randomUUID(),
        ...cityData,
        createdAt: new Date(),
      };
      this.cities.set(city.id, city);
    });

    // Initialize businesses for each city
    this.initializeBusinesses();
  }

  private initializeCategories() {
    const categoriesData: InsertBusinessCategory[] = [
      {
        name: "Transporte",
        slug: "transport",
        icon: "Bus",
        color: "blue",
        description: "Empresas de transporte público, táxi, ônibus e fretamento",
        isActive: true,
      },
      {
        name: "Restaurantes",
        slug: "restaurants",
        icon: "UtensilsCrossed",
        color: "orange",
        description: "Restaurantes, lanchonetes, pizzarias e delivery",
        isActive: true,
      },
      {
        name: "Hotéis e Pousadas",
        slug: "hotels",
        icon: "Bed",
        color: "purple",
        description: "Hotéis, pousadas, motéis e hospedagem",
        isActive: true,
      },
      {
        name: "Saúde",
        slug: "health",
        icon: "Heart",
        color: "red",
        description: "Farmácias, clínicas, laboratórios e consultórios",
        isActive: true,
      },
      {
        name: "Serviços",
        slug: "services",
        icon: "Wrench",
        color: "green",
        description: "Oficinas, salões, lavanderias e serviços gerais",
        isActive: true,
      },
      {
        name: "Comércio",
        slug: "retail",
        icon: "ShoppingBag",
        color: "indigo",
        description: "Lojas, supermercados, farmácias e varejo",
        isActive: true,
      },
      {
        name: "Educação",
        slug: "education",
        icon: "GraduationCap",
        color: "cyan",
        description: "Escolas, cursos, universidades e ensino",
        isActive: true,
      },
      {
        name: "Lazer e Turismo",
        slug: "leisure",
        icon: "Camera",
        color: "pink",
        description: "Pontos turísticos, parques, eventos e entretenimento",
        isActive: true,
      },
    ];

    categoriesData.forEach(categoryData => {
      const category: BusinessCategory = {
        id: randomUUID(),
        ...categoryData,
      };
      this.businessCategories.set(category.id, category);
    });
  }

  private initializeBusinesses() {
    const saoJoseCity = Array.from(this.cities.values()).find(c => c.slug === "sao-jose-da-lapa");
    const vespasianoCity = Array.from(this.cities.values()).find(c => c.slug === "vespasiano");
    const pedroLeopoldoCity = Array.from(this.cities.values()).find(c => c.slug === "pedro-leopoldo");
    const lagoaSantaCity = Array.from(this.cities.values()).find(c => c.slug === "lagoa-santa");
    const ribeiraoCity = Array.from(this.cities.values()).find(c => c.slug === "ribeirao-das-neves");
    const confinsCity = Array.from(this.cities.values()).find(c => c.slug === "confins");

    const businessesData: InsertBusiness[] = [
      // São José da Lapa - Transporte
      {
        cityId: saoJoseCity?.id || "",
        name: "Viação União Norte",
        slug: "viacao-uniao-norte",
        category: "transport",
        subcategory: "bus",
        phone: "(31) 3689-1234",
        whatsapp: "5531368912234",
        email: "contato@viacaouniaonorte.com.br",
        website: "https://viacaouniaonorte.com.br",
        address: "Rua Principal, 1500",
        neighborhood: "Centro",
        postalCode: "33350-000",
        coordinates: "-19.7850,-44.1450",
        banner: "/banners/company-uniao-norte.jpg",
        images: ["/images/uniao-norte-1.jpg", "/images/uniao-norte-2.jpg"],
        description: "Empresa de transporte coletivo especializada em linhas metropolitanas. Atende São José da Lapa e região há mais de 20 anos.",
        services: ["Transporte Urbano", "Linhas Metropolitanas", "Fretamento", "Turismo"],
        workingHours: {
          "monday": { "open": "05:00", "close": "23:00" },
          "tuesday": { "open": "05:00", "close": "23:00" },
          "wednesday": { "open": "05:00", "close": "23:00" },
          "thursday": { "open": "05:00", "close": "23:00" },
          "friday": { "open": "05:00", "close": "23:00" },
          "saturday": { "open": "06:00", "close": "22:00" },
          "sunday": { "open": "07:00", "close": "21:00" }
        },
        priceRange: "$$",
        rating: 4,
        reviewCount: 89,
        isVerified: true,
        isActive: true,
      },
      {
        cityId: saoJoseCity?.id || "",
        name: "TransLapa",
        slug: "translapa",
        category: "transport",
        subcategory: "cooperative",
        phone: "(31) 3689-5678",
        whatsapp: "5531368956578",
        email: "atendimento@translapa.com.br",
        address: "Avenida Industrial, 890",
        neighborhood: "Distrito Industrial",
        postalCode: "33350-100",
        coordinates: "-19.7820,-44.1420",
        banner: "/banners/company-translapa.jpg",
        images: ["/images/translapa-1.jpg"],
        description: "Cooperativa de transporte local com foco na qualidade do atendimento e pontualidade.",
        services: ["Transporte Urbano", "Linhas Industriais", "Transporte Escolar"],
        workingHours: {
          "monday": { "open": "05:30", "close": "22:30" },
          "tuesday": { "open": "05:30", "close": "22:30" },
          "wednesday": { "open": "05:30", "close": "22:30" },
          "thursday": { "open": "05:30", "close": "22:30" },
          "friday": { "open": "05:30", "close": "22:30" },
          "saturday": { "open": "05:30", "close": "22:30" },
          "sunday": { "open": "05:30", "close": "22:30" }
        },
        priceRange: "$",
        rating: 4,
        reviewCount: 45,
        isVerified: false,
        isActive: true,
      },
      
      // São José da Lapa - Restaurantes
      {
        cityId: saoJoseCity?.id || "",
        name: "Pizzaria do Zé",
        slug: "pizzaria-do-ze",
        category: "restaurants",
        subcategory: "pizza",
        phone: "(31) 3689-8888",
        whatsapp: "5531368988888",
        address: "Rua das Flores, 245",
        neighborhood: "Centro",
        postalCode: "33350-000",
        coordinates: "-19.7840,-44.1440",
        banner: "/banners/pizzaria-ze.jpg",
        description: "Pizzaria tradicional com mais de 15 anos servindo as melhores pizzas da região.",
        services: ["Pizza", "Delivery", "Refrigerantes", "Sobremesas"],
        workingHours: {
          "tuesday": { "open": "18:00", "close": "23:00" },
          "wednesday": { "open": "18:00", "close": "23:00" },
          "thursday": { "open": "18:00", "close": "23:00" },
          "friday": { "open": "18:00", "close": "24:00" },
          "saturday": { "open": "18:00", "close": "24:00" },
          "sunday": { "open": "18:00", "close": "23:00" }
        },
        priceRange: "$$",
        rating: 5,
        reviewCount: 127,
        isVerified: true,
        isActive: true,
      },
      
      // São José da Lapa - Saúde
      {
        cityId: saoJoseCity?.id || "",
        name: "Farmácia Popular",
        slug: "farmacia-popular",
        category: "health",
        subcategory: "pharmacy",
        phone: "(31) 3689-2200",
        whatsapp: "5531368922200",
        address: "Praça Central, 89",
        neighborhood: "Centro",
        postalCode: "33350-000",
        coordinates: "-19.7845,-44.1445",
        banner: "/banners/farmacia-popular.jpg",
        description: "Farmácia completa com medicamentos, perfumaria e conveniência. Atendimento 24h.",
        services: ["Medicamentos", "Perfumaria", "Conveniência", "Delivery"],
        workingHours: {
          "monday": { "open": "00:00", "close": "23:59" },
          "tuesday": { "open": "00:00", "close": "23:59" },
          "wednesday": { "open": "00:00", "close": "23:59" },
          "thursday": { "open": "00:00", "close": "23:59" },
          "friday": { "open": "00:00", "close": "23:59" },
          "saturday": { "open": "00:00", "close": "23:59" },
          "sunday": { "open": "00:00", "close": "23:59" }
        },
        priceRange: "$",
        rating: 4,
        reviewCount: 78,
        isVerified: true,
        isActive: true,
      },
      
      // Vespasiano
      {
        cityId: vespasianoCity?.id || "",
        name: "Expresso Vespasiano",
        slug: "expresso-vespasiano",
        phone: "(31) 3621-9000",
        whatsapp: "5531362190000",
        email: "sac@expressovespasiano.com.br",
        website: "https://expressovespasiano.com.br",
        address: "Rua das Palmeiras, 2100",
        neighborhood: "Centro",
        postalCode: "33200-000",
        banner: "/banners/company-expresso-vespasiano.jpg",
        description: "Principal empresa de transporte de Vespasiano, conectando a cidade a Belo Horizonte e região metropolitana.",
        services: ["Transporte Metropolitano", "Linhas Expressas", "Transporte Executivo", "Fretamento"],
        workingHours: "24 horas - Central de Atendimento",
        isActive: true,
      },
      {
        cityId: vespasianoCity?.id || "",
        name: "Coletivo Norte",
        slug: "coletivo-norte",
        phone: "(31) 3621-4500",
        whatsapp: "5531362145000",
        email: "contato@coletivonoerte.com.br",
        address: "Avenida São Paulo, 750",
        neighborhood: "Morro Alto",
        postalCode: "33200-200",
        banner: "/banners/company-coletivo-norte.jpg",
        description: "Cooperativa que atende os bairros periféricos de Vespasiano com qualidade e preços acessíveis.",
        services: ["Transporte Urbano", "Linhas de Bairro", "Transporte Escolar", "Linha Social"],
        workingHours: "Segunda a Sábado: 5h às 23h | Domingo: 6h às 22h",
        isActive: true,
      },

      // Pedro Leopoldo
      {
        cityId: pedroLeopoldoCity?.id || "",
        name: "Viação Pedro Leopoldo",
        slug: "viacao-pedro-leopoldo",
        phone: "(31) 3661-2200",
        whatsapp: "5531366122200",
        email: "atendimento@viacaopedroleopoldo.com.br",
        address: "Praça Tiradentes, 45",
        neighborhood: "Centro",
        postalCode: "33600-000",
        banner: "/banners/company-pedro-leopoldo.jpg",
        description: "Tradicional empresa familiar que opera há 30 anos na região, conhecida pela pontualidade e conforto.",
        services: ["Transporte Intermunicipal", "Linhas Turísticas", "Fretamento", "Excursões"],
        workingHours: "Segunda a Sexta: 6h às 20h | Sábado: 7h às 18h",
        isActive: true,
      },

      // Lagoa Santa
      {
        cityId: lagoaSantaCity?.id || "",
        name: "Lagoa Santa Transportes",
        slug: "lagoa-santa-transportes",
        phone: "(31) 3681-3300",
        whatsapp: "5531368133300",
        email: "contato@lagoasantatransportes.com.br",
        website: "https://lagoasantatransportes.com.br",
        address: "Rua da Lagoa, 300",
        neighborhood: "Centro",
        postalCode: "33400-000",
        banner: "/banners/company-lagoa-santa.jpg",
        description: "Empresa especializada em turismo ecológico e transporte para as lagoas da região.",
        services: ["Transporte Turístico", "Linhas Metropolitanas", "Excursões Ecológicas", "Transfer Aeroporto"],
        workingHours: "Todos os dias: 6h às 21h",
        isActive: true,
      },

      // Ribeirão das Neves  
      {
        cityId: ribeiraoCity?.id || "",
        name: "Mega Transportes",
        slug: "mega-transportes",
        phone: "(31) 3623-8000",
        whatsapp: "5531362388000",
        email: "sac@megatransportes.com.br",
        website: "https://megatransportes.com.br",
        address: "Avenida Brasil, 1200",
        neighborhood: "Centro",
        postalCode: "33800-000",
        banner: "/banners/company-mega-transportes.jpg",
        description: "Maior empresa de transporte da região, com frota moderna e tecnologia de ponta.",
        services: ["Transporte Metropolitano", "Linhas Expressas", "BRT", "Transporte Corporativo"],
        workingHours: "24 horas - Atendimento e Operação",
        isActive: true,
      },

      // Confins
      {
        cityId: confinsCity?.id || "",
        name: "Aeroporto Confins Transportes",
        slug: "aeroporto-confins-transportes",
        phone: "(31) 3689-9900",
        whatsapp: "5531368999900",
        email: "reservas@aeroportoconfins.com.br",
        website: "https://aeroportoconfins.com.br",
        address: "Terminal Rodoviário do Aeroporto",
        neighborhood: "Aeroporto",
        postalCode: "33500-900",
        banner: "/banners/company-aeroporto-confins.jpg",
        description: "Especializada em transfer e conexões com o Aeroporto Internacional de Confins.",
        services: ["Transfer Aeroporto", "Conexões Metropolitanas", "Transporte Executivo", "Turismo Corporativo"],
        workingHours: "24 horas - Acompanha voos",
        isActive: true,
      }
    ];

    // Create businesses
    businessesData.forEach(businessData => {
      const business: Business = {
        id: randomUUID(),
        ...businessData,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.businesses.set(business.id, business);
    });
  }

  // Cities methods
  async getCities(): Promise<City[]> {
    return Array.from(this.cities.values()).filter(city => city.isActive);
  }

  async getCity(slug: string): Promise<City | undefined> {
    return Array.from(this.cities.values()).find(city => city.slug === slug && city.isActive);
  }

  async getCityWithCompanies(slug: string): Promise<CityWithCompanies | undefined> {
    const city = await this.getCity(slug);
    if (!city) return undefined;

    const companies = await this.getTransportCompaniesByCity(city.id);
    return {
      ...city,
      companies,
    };
  }

  async createCity(cityData: InsertCity): Promise<City> {
    const city: City = {
      id: randomUUID(),
      ...cityData,
      createdAt: new Date(),
    };
    this.cities.set(city.id, city);
    return city;
  }

  // Transport Companies methods
  async getTransportCompanies(): Promise<TransportCompany[]> {
    return Array.from(this.transportCompanies.values()).filter(company => company.isActive);
  }

  async getTransportCompaniesByCity(cityId: string): Promise<TransportCompany[]> {
    return Array.from(this.transportCompanies.values()).filter(
      company => company.cityId === cityId && company.isActive
    );
  }

  async getTransportCompany(id: string): Promise<TransportCompany | undefined> {
    return this.transportCompanies.get(id);
  }

  async createTransportCompany(companyData: InsertTransportCompany): Promise<TransportCompany> {
    const company: TransportCompany = {
      id: randomUUID(),
      ...companyData,
      createdAt: new Date(),
    };
    this.transportCompanies.set(company.id, company);
    return company;
  }
}

export const citiesStorage = new MemCitiesStorage();