# Overview

This is a comprehensive bus schedule Progressive Web App (PWA) for the São José da Lapa region and north metro area of Belo Horizonte, Brazil. The application provides offline-capable bus schedule lookup with real-time features, favorites management, and a modern mobile-first interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with **React 18** using **Vite** as the build tool for fast development and optimized production builds. The application follows a component-based architecture with modular, reusable UI components.

**UI Framework**: Uses **shadcn/ui** component library built on top of **Radix UI** primitives, providing accessible and customizable components. The design system is implemented with **Tailwind CSS** using a custom color scheme optimized for transportation apps.

**State Management**: Utilizes **TanStack Query (React Query)** for server state management, caching, and synchronization. Local state is managed through React hooks and context where appropriate.

**Routing**: Implements client-side routing with **Wouter**, a lightweight alternative to React Router, supporting the main navigation structure (Home, Lines, Map, Settings).

**PWA Implementation**: Full Progressive Web App capabilities including:
- Service worker for offline functionality and caching
- Web app manifest for installability
- Responsive design optimized for mobile devices
- Touch-friendly interactions and Material Design principles

## Backend Architecture
The backend follows a **REST API** architecture built with **Express.js** and **TypeScript**. The server provides JSON endpoints for bus lines, schedules, live updates, and user favorites.

**API Structure**: RESTful endpoints including:
- `/api/lines` - Bus line management and search
- `/api/schedules` - Schedule data for specific lines
- `/api/live-updates` - Real-time service announcements
- `/api/regions` - City region information
- `/api/favorites` - User favorite lines management

**Data Storage**: Uses an in-memory storage implementation (`MemStorage`) that simulates database operations. The system is designed to easily swap to a database implementation when needed.

**Development Setup**: Vite middleware integration allows for hot module replacement during development, with production builds serving static assets through Express.

## Data Management
**Schema Definition**: Shared TypeScript schemas using **Drizzle ORM** and **Zod** for validation, ensuring type safety across the entire application stack.

**Caching Strategy**: Multi-layered caching approach:
- Service worker caches static assets and API responses
- React Query handles client-side data caching with automatic invalidation
- localStorage fallback for critical data when offline

**Offline Capability**: Cache-first strategy where the service worker serves cached content when available, falling back to network requests. Critical schedule data is persisted locally for offline access.

# External Dependencies

## Database System
**Drizzle ORM**: Modern TypeScript ORM configured for PostgreSQL with schema migrations. Currently uses in-memory storage but structured for easy database integration.

**Neon Database**: PostgreSQL service integration prepared through `@neondatabase/serverless` package for production deployment.

## UI and Styling
**Tailwind CSS**: Utility-first CSS framework with custom design system optimized for transportation apps and mobile interfaces.

**Radix UI**: Unstyled, accessible component primitives providing the foundation for the design system.

**shadcn/ui**: Pre-built component library providing consistent, accessible UI components.

## Development and Build Tools
**Vite**: Modern build tool providing fast development server with hot module replacement and optimized production builds.

**TypeScript**: Full type safety across client, server, and shared code with path mapping for clean imports.

**ESLint**: Code quality enforcement with React-specific rules and hooks validation.

## PWA and Mobile Features
**Service Worker**: Custom implementation for caching strategies and offline functionality.

**Web App Manifest**: Complete PWA manifest supporting installation and native app-like experience.

**Geolocation API**: Browser geolocation integration for finding nearby bus stops and routes.

## Query and State Management
**TanStack Query**: Server state management with automatic caching, background updates, and optimistic updates.

**React Hook Form**: Form management with validation integration.

**Wouter**: Lightweight client-side routing optimized for small bundle size.

# Recent Changes

## Real-Time API Integration (September 2025)

**Enhanced Data Sources**: Integrated with official transport APIs for authentic data:
- **BHTrans Real-Time API**: GPS positioning data updated every 20 seconds from `temporeal.pbh.gov.br`
- **Enhanced Schedule Generation**: Realistic timetables based on actual BH Norte region line patterns
- **Fallback System**: Graceful degradation when external APIs are unavailable

**New External API Endpoints**:
- `/api/external/schedule/:lineNumber/:type` - Real-time schedule data with enhanced generation
- `/api/external/realtime-positions` - Live bus GPS positions from BHTrans or intelligent simulation  
- `/api/external/route/:lineNumber` - Enhanced route information and fare data

**Real-Time Features**:
- Live bus position tracking with 20-second updates
- Enhanced schedule modal with real-time/offline toggle
- Automatic fallback to simulated realistic data when APIs are unavailable
- Visual indicators for data sources (real-time vs offline)

**User Experience Improvements**:
- Real-time status component showing live bus positions
- Enhanced visual design with gradients and modern animations
- Improved filtering system by region on lines page
- Commercial-grade interface optimized for mobile usage

**Technical Implementation**:
- **RealTimeService**: TypeScript service for API integration with error handling
- **Enhanced APIs**: Intelligent data generation when external sources unavailable
- **Position Simulation**: Realistic GPS coordinates around BH Norte region
- **Schedule Generation**: Algorithm-based timetables matching real transport patterns