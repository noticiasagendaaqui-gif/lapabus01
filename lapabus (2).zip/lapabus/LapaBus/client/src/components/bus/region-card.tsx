import { Button } from "@/components/ui/button";
import type { CityRegion } from "@shared/schema";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface RegionCardProps {
  region: CityRegion;
  onClick?: () => void;
}

export function RegionCard({ region, onClick }: RegionCardProps) {
  const getGradientClass = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-gradient-to-br from-primary to-primary/80";
      case "secondary":
        return "bg-gradient-to-br from-secondary to-secondary/80";
      case "accent":
        return "bg-gradient-to-br from-accent to-accent/80";
      case "muted":
        return "bg-gradient-to-br from-muted to-muted/80";
      default:
        return "bg-gradient-to-br from-primary to-primary/80";
    }
  };

  const getTextColor = (color: string) => {
    switch (color) {
      case "muted":
        return "text-muted-foreground";
      default:
        return "text-white";
    }
  };

  return (
    <Button
      variant="ghost"
      className={cn(
        "h-auto p-5 material-elevation-2 touch-target animate-fade-in text-left group transition-all duration-300 hover:scale-105",
        getGradientClass(region.color || "primary"),
        getTextColor(region.color || "primary")
      )}
      onClick={onClick}
      data-testid={`region-card-${region.slug}`}
    >
      <div className="w-full relative">
        <div className="absolute top-0 right-0 w-8 h-8 bg-white/10 rounded-full group-hover:scale-150 transition-transform duration-500"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-base">{region.name}</h3>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </div>
          <div className="flex items-center mb-3">
            <div className="w-2 h-2 bg-white/60 rounded-full mr-2"></div>
            <span className="text-sm font-medium opacity-95">
              {region.lineCount} linhas ativas
            </span>
          </div>
          <p className="text-xs opacity-80">
            {region.description}
          </p>
        </div>
      </div>
    </Button>
  );
}
