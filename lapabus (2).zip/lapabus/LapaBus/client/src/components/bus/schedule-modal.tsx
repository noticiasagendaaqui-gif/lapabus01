import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { BusSchedule } from "@shared/schema";
import { Share2, Bell, X, Wifi, WifiOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { realTimeService, type RealTimeSchedule } from "@/services/realTimeService";
import { useState, useEffect } from "react";

interface ScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  lineId: string;
  lineName: string;
  lineNumber?: string; // For OpenBHBus API integration
}

export function ScheduleModal({ isOpen, onClose, lineId, lineName, lineNumber }: ScheduleModalProps) {
  const { toast } = useToast();
  const [realTimeSchedule, setRealTimeSchedule] = useState<RealTimeSchedule | null>(null);
  const [isRealTimeLoading, setIsRealTimeLoading] = useState(false);
  const [useRealTime, setUseRealTime] = useState(false);
  
  // Fallback to local schedules
  const { data: schedules, isLoading } = useQuery<{ success: boolean; data: BusSchedule[] }>({
    queryKey: ["/api/lines", lineId, "schedules"],
    enabled: isOpen && !useRealTime,
  });

  // Load real-time schedule when modal opens and line number is available
  useEffect(() => {
    if (isOpen && lineNumber) {
      loadRealTimeSchedule();
    }
  }, [isOpen, lineNumber]);

  const loadRealTimeSchedule = async () => {
    if (!lineNumber) return;
    
    setIsRealTimeLoading(true);
    try {
      const scheduleType = realTimeService.getCurrentScheduleType();
      const realSchedule = await realTimeService.getSchedule(lineNumber, scheduleType);
      
      if (realSchedule && realSchedule.schedules.length > 0) {
        setRealTimeSchedule(realSchedule);
        setUseRealTime(true);
        toast({
          title: "📡 Dados Reais Carregados",
          description: "Horários atualizados da API OpenBHBus",
        });
      }
    } catch (error) {
      console.warn('Failed to load real-time schedule:', error);
    } finally {
      setIsRealTimeLoading(false);
    }
  };

  const getCurrentSchedules = () => {
    if (useRealTime && realTimeSchedule) {
      return realTimeSchedule.schedules;
    }
    return schedules?.data?.map(s => s.departureTime) || [];
  };

  const handleShare = async () => {
    const currentSchedules = getCurrentSchedules();
    const source = useRealTime ? " (Dados Reais OpenBHBus)" : "";
    const scheduleText = `Horários da ${lineName}${source}:\n${currentSchedules.join(", ")}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: lineName,
          text: scheduleText,
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(scheduleText);
        toast({
          title: "Horários copiados",
          description: "Horários copiados para área de transferência",
        });
      } catch (error) {
        toast({
          title: "Erro",
          description: "Não foi possível copiar os horários",
          variant: "destructive",
        });
      }
    }
  };

  const handleSetAlert = () => {
    toast({
      title: "Alerta configurado",
      description: "Você será notificado sobre esta linha",
    });
  };

  const getCurrentTimeClass = (time: string) => {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    if (time === currentTime) {
      return "bg-destructive text-destructive-foreground"; // Current time
    } else if (time > currentTime) {
      const [hours, minutes] = time.split(':').map(Number);
      const [currentHours, currentMinutes] = currentTime.split(':').map(Number);
      const timeInMinutes = hours * 60 + minutes;
      const currentTimeInMinutes = currentHours * 60 + currentMinutes;
      
      if (timeInMinutes - currentTimeInMinutes <= 30) {
        return "bg-accent text-accent-foreground"; // Next departure
      }
    }
    
    return "bg-muted text-muted-foreground";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span data-testid="schedule-modal-title">Horários - {lineName}</span>
              {useRealTime ? (
                <Badge variant="secondary" className="text-xs animate-pulse">
                  <Wifi className="w-3 h-3 mr-1" />
                  Tempo Real
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs">
                  <WifiOff className="w-3 h-3 mr-1" />
                  Offline
                </Badge>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-modal"
            >
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Real-time toggle */}
          {lineNumber && !isRealTimeLoading && (
            <div className="flex items-center justify-between p-2 bg-muted rounded-lg">
              <span className="text-sm text-muted-foreground">
                {useRealTime ? 'Usando dados em tempo real' : 'Dados locais'}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (useRealTime) {
                    setUseRealTime(false);
                  } else {
                    loadRealTimeSchedule();
                  }
                }}
                className="text-xs"
              >
                {useRealTime ? 'Usar Offline' : 'Atualizar'}
              </Button>
            </div>
          )}
          
          {isLoading || isRealTimeLoading ? (
            <div className="grid grid-cols-3 gap-2">
              {[...Array(9)].map((_, i) => (
                <Skeleton key={i} className="h-12 rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-2 max-h-80 overflow-y-auto">
              {getCurrentSchedules().map((time, index) => (
                <div
                  key={useRealTime ? `real-${index}` : `local-${index}`}
                  className={cn(
                    "p-3 rounded-lg text-center transition-colors",
                    getCurrentTimeClass(time)
                  )}
                  data-testid={`schedule-time-${time}`}
                >
                  <span className="font-mono text-sm font-medium">
                    {time}
                  </span>
                  {getCurrentTimeClass(time).includes('accent') && (
                    <div className="text-xs opacity-75 mt-1">Próximo</div>
                  )}
                </div>
              ))}
            </div>
          )}
          
          <div className="flex space-x-2 pt-4">
            <Button 
              className="flex-1 touch-target"
              onClick={handleShare}
              data-testid="button-share-schedule"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Compartilhar
            </Button>
            <Button 
              variant="secondary"
              className="flex-1 touch-target"
              onClick={handleSetAlert}
              data-testid="button-set-alert"
            >
              <Bell className="w-4 h-4 mr-2" />
              Alerta
            </Button>
          </div>
          
          {useRealTime && realTimeSchedule && (
            <div className="text-center text-xs text-muted-foreground mt-2">
              Dados fornecidos por {realTimeSchedule.source} • Tipo: {realTimeSchedule.type}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
