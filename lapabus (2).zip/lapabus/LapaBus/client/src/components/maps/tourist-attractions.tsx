import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  MapPin, 
  Search, 
  ExternalLink, 
  Navigation, 
  Phone,
  Globe,
  Star,
  Clock,
  Filter
} from "lucide-react";
import { mapsService, type TouristAttraction } from "@/services/mapsService";

interface TouristAttractionsProps {
  cityName?: string;
  stateName?: string;
}

export function TouristAttractions({ cityName = "", stateName = "MG" }: TouristAttractionsProps) {
  const [searchQuery, setSearchQuery] = useState(cityName);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { data: attractions = [], isLoading, refetch } = useQuery({
    queryKey: ["tourist-attractions", searchQuery, stateName],
    queryFn: async () => {
      if (!searchQuery.trim()) {
        return mapsService.getPopularAttractions();
      }
      
      const searchResults = await mapsService.searchTouristAttractions(searchQuery, stateName);
      
      // If no results from API, return popular attractions as fallback
      if (searchResults.length === 0) {
        return mapsService.getPopularAttractions();
      }
      
      return searchResults;
    },
    enabled: true,
  });

  const categories = ["all", "Turismo", "História", "Natureza", "Serviços", "Lazer"];
  
  const filteredAttractions = selectedCategory === "all" 
    ? attractions 
    : attractions.filter(attraction => attraction.category === selectedCategory);

  const handleSearch = () => {
    refetch();
  };

  const handleViewOnMap = (attraction: TouristAttraction) => {
    const mapUrl = mapsService.generateMapUrl(attraction.lat, attraction.lon, 16);
    window.open(mapUrl, '_blank');
  };

  const handleGetDirections = async (attraction: TouristAttraction) => {
    const currentLocation = await mapsService.getCurrentLocation();
    
    if (!currentLocation) {
      // Fallback to center of BH Norte region
      const fallbackUrl = mapsService.generateDirectionsUrl(
        -19.6920, -44.0080, // Vespasiano center
        attraction.lat, attraction.lon
      );
      window.open(fallbackUrl, '_blank');
      return;
    }
    
    const directionsUrl = mapsService.generateDirectionsUrl(
      currentLocation.lat, currentLocation.lon,
      attraction.lat, attraction.lon
    );
    window.open(directionsUrl, '_blank');
  };

  const renderStars = (rating?: number) => {
    if (!rating) return null;
    
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`h-4 w-4 ${
              i < rating 
                ? 'fill-yellow-400 text-yellow-400' 
                : 'text-gray-300 dark:text-gray-600'
            }`}
          />
        ))}
        <span className="text-sm text-gray-600 dark:text-gray-300 ml-1">
          {rating.toFixed(1)}
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Pontos Turísticos
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          Descubra atrações e pontos de interesse na região
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1">
            <Input
              placeholder="Buscar por cidade..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
              data-testid="input-search-attractions"
            />
          </div>
          <Button 
            onClick={handleSearch}
            disabled={isLoading}
            data-testid="button-search-attractions"
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <Filter className="h-4 w-4 text-gray-500 flex-shrink-0" />
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              className="whitespace-nowrap"
              data-testid={`filter-category-${category}`}
            >
              {category === "all" ? "Todos" : category}
            </Button>
          ))}
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Attractions Grid */}
      {!isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAttractions.map((attraction) => (
            <Card 
              key={attraction.id} 
              className="bg-gradient-to-br from-white to-blue-50 dark:from-gray-800 dark:to-gray-900 border border-blue-100 dark:border-blue-800"
              data-testid={`card-attraction-${attraction.id}`}
            >
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="secondary" className="text-xs">
                    {attraction.category}
                  </Badge>
                  {renderStars(attraction.rating)}
                </div>
                
                <CardTitle className="text-lg text-gray-900 dark:text-white">
                  {attraction.name}
                </CardTitle>
                
                <CardDescription className="text-gray-600 dark:text-gray-300">
                  {attraction.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Location */}
                <div className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-300">
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>{attraction.city}, {attraction.state}</span>
                </div>

                {/* Opening Hours */}
                {attraction.opening_hours && (
                  <div className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-300">
                    <Clock className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{attraction.opening_hours}</span>
                  </div>
                )}

                {/* Contact Info */}
                {attraction.contact && (
                  <div className="space-y-2">
                    {attraction.contact.phone && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="h-4 w-4 text-gray-500" />
                        <a 
                          href={`tel:${attraction.contact.phone}`}
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                        >
                          {attraction.contact.phone}
                        </a>
                      </div>
                    )}
                    
                    {attraction.contact.website && (
                      <div className="flex items-center gap-2 text-sm">
                        <Globe className="h-4 w-4 text-gray-500" />
                        <a 
                          href={attraction.contact.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                        >
                          Site oficial
                          <ExternalLink className="h-3 w-3 ml-1 inline" />
                        </a>
                      </div>
                    )}
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2 border-t border-gray-100 dark:border-gray-700">
                  <Button
                    onClick={() => handleViewOnMap(attraction)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    data-testid={`button-view-map-${attraction.id}`}
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    Ver no mapa
                  </Button>
                  
                  <Button
                    onClick={() => handleGetDirections(attraction)}
                    variant="default"
                    size="sm"
                    className="flex-1"
                    data-testid={`button-directions-${attraction.id}`}
                  >
                    <Navigation className="h-4 w-4 mr-2" />
                    Rotas
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && filteredAttractions.length === 0 && (
        <div className="text-center py-12">
          <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Nenhuma atração encontrada
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Tente buscar por uma cidade diferente ou ajustar os filtros.
          </p>
          <Button 
            onClick={() => {
              setSearchQuery("");
              setSelectedCategory("all");
              refetch();
            }}
            variant="outline"
          >
            Ver atrações populares
          </Button>
        </div>
      )}
    </div>
  );
}