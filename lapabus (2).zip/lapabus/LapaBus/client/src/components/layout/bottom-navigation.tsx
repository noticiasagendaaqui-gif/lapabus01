import { useLocation } from "wouter";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Route, Map, Settings, Building2 } from "lucide-react";

const navigationItems = [
  { path: "/", icon: Home, label: "Início" },
  { path: "/lines", icon: Route, label: "Linhas" },
  { path: "/cities", icon: Building2, label: "Cidades" },
  { path: "/map", icon: Map, label: "Mapa" },
  { path: "/settings", icon: Settings, label: "Config" },
];

export function BottomNavigation() {
  const [location] = useLocation();

  return (
    <nav className="glass-effect border-t border-border material-elevation-2 sticky bottom-0 z-50">
      <div className="grid grid-cols-5 h-16">
        {navigationItems.map(({ path, icon: Icon, label }) => (
          <Link
            key={path}
            href={path}
            className={cn(
              "flex flex-col items-center justify-center space-y-1 touch-target ripple-effect transition-colors",
              location === path
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            )}
            data-testid={`nav-${label.toLowerCase()}`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-xs font-medium">{label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}
