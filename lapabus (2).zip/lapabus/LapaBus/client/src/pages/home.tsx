import { useQuery } from "@tanstack/react-query";
import { SearchBar } from "@/components/bus/search-bar";
import { LineCard } from "@/components/bus/line-card";
import { RegionCard } from "@/components/bus/region-card";
import { LiveUpdate } from "@/components/bus/live-update";
import { RealTimeStatus } from "@/components/bus/real-time-status";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LocationBanner } from "@/components/location/location-banner";
import { useLocation } from "@/contexts/LocationContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useToast } from "@/hooks/use-toast";
import type { BusLine, CityRegion, LiveUpdate as LiveUpdateType } from "@shared/schema";
import { Clock, MapPin, Star, Bell, Share2, Building2, Users, Phone, ExternalLink, Bus, UtensilsCrossed, Bed, Heart, Wrench, ShoppingBag, GraduationCap, Camera } from "lucide-react";
import { useState, useEffect } from "react";
import { Link } from "wouter";

export default function Home() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const { toast } = useToast();
  const { getCurrentPosition } = useGeolocation();
  const { selectedCity } = useLocation();

  // Queries for business directory data
  const { data: cities, isLoading: citiesLoading } = useQuery({
    queryKey: ["/api/cities"],
    queryFn: async () => {
      const response = await fetch("/api/cities");
      const result = await response.json();
      return result.data;
    },
  });

  const { data: businessCategories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      const result = await response.json();
      return result.data;
    },
  });

  const { data: recentBusinesses } = useQuery({
    queryKey: ["/api/businesses", selectedCity?.id],
    queryFn: async () => {
      let url = "/api/businesses";
      if (selectedCity?.id) {
        url += `?city=${selectedCity.id}`;
      }
      const response = await fetch(url);
      const result = await response.json();
      return result.data?.slice(0, 4); // Get first 4 businesses
    },
  });

  // Keep some original queries for secondary sections
  const { data: busLines, isLoading: linesLoading } = useQuery<{ success: boolean; data: BusLine[] }>({
    queryKey: ["/api/lines"],
  });

  const { data: regions } = useQuery<{ success: boolean; data: CityRegion[] }>({
    queryKey: ["/api/regions"],
  });

  const { data: liveUpdates } = useQuery<{ success: boolean; data: LiveUpdateType[] }>({
    queryKey: ["/api/live-updates"],
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const handleFindNearby = async () => {
    try {
      const position = await getCurrentPosition();
      toast({
        title: "Localização encontrada",
        description: "Buscando paradas próximas...",
      });
      // TODO: Implement nearby stops search with coordinates
    } catch (error) {
      toast({
        title: "Erro de localização",
        description: "Não foi possível acessar sua localização",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Guia Horários BH Norte',
          text: 'Consulte horários de ônibus da região metropolitana',
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled share
      }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        toast({
          title: "Link copiado",
          description: "Link copiado para área de transferência",
        });
      } catch (error) {
        toast({
          title: "Erro",
          description: "Não foi possível copiar o link",
          variant: "destructive",
        });
      }
    }
  };

  const timeString = currentTime.toLocaleTimeString('pt-BR', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  const recentLines = busLines?.data?.slice(0, 2) || [];
  const featuredCities = cities?.slice(0, 4) || [];
  const topCategories = businessCategories?.slice(0, 8) || [];

  // Icon mapping for categories
  const getCategoryIcon = (slug: string) => {
    const iconMap: { [key: string]: React.ComponentType<any> } = {
      transport: Bus,
      restaurants: UtensilsCrossed,
      hotels: Bed,
      health: Heart,
      services: Wrench,
      retail: ShoppingBag,
      education: GraduationCap,
      leisure: Camera,
    };
    return iconMap[slug] || Building2;
  };

  const formatPopulation = (population: number | null) => {
    if (!population) return "N/A";
    return new Intl.NumberFormat("pt-BR").format(population);
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header - Commercial Guide Focus */}
      <div className="space-y-6">
        <div className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-secondary p-6 rounded-2xl text-white material-elevation-2">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold mb-1">Guia Comercial BH Norte</h1>
                <p className="text-white/90 text-sm">Encontre empresas e serviços da região metropolitana</p>
              </div>
              <div className="text-right">
                <div className="flex items-center text-white/90 text-sm mb-1">
                  <Building2 className="w-4 h-4 mr-1" />
                  <span>{cities?.length || 0} cidades</span>
                </div>
                <div className="flex items-center text-white/90 text-sm">
                  <Users className="w-4 h-4 mr-1" />
                  <span>{recentBusinesses?.length || 0}+ empresas</span>
                </div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-1">
              <SearchBar className="bg-white/20 border-0 text-white placeholder:text-white/70" placeholder="Buscar empresas, serviços..." />
            </div>
          </div>
        </div>
      </div>

      {/* Location Detection Banner */}
      <LocationBanner />

      {/* Business Categories */}
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-foreground flex items-center">
            <div className="w-1 h-6 bg-gradient-to-b from-primary to-secondary rounded-full mr-3"></div>
            Categorias de Negócios
          </h2>
          <Link href="/businesses">
            <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 rounded-xl">
              Ver todas →
            </Button>
          </Link>
        </div>
        
        {categoriesLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-16 bg-muted rounded-lg" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {topCategories.slice(0, 6).map((category: any) => {
              const IconComponent = getCategoryIcon(category.slug);
              return (
                <Link key={category.id} href={`/businesses/${category.slug}`}>
                  <Button 
                    variant="outline"
                    className="h-auto p-4 w-full bg-gradient-to-br from-white to-gray-50 hover:from-gray-50 hover:to-gray-100 material-elevation-1 touch-target group transition-all duration-300 border border-gray-200"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 bg-${category.color}-100 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <IconComponent className={`w-5 h-5 text-${category.color}-600`} />
                      </div>
                      <div className="text-left flex-1">
                        <span className="text-sm font-semibold block text-foreground">{category.name}</span>
                        <span className="text-xs text-muted-foreground">{category.description?.split(',')[0]}...</span>
                      </div>
                    </div>
                  </Button>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* Featured Cities */}
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-foreground flex items-center">
            <div className="w-1 h-6 bg-gradient-to-b from-secondary to-accent rounded-full mr-3"></div>
            {selectedCity ? `Explorando ${selectedCity.name}` : 'Cidades em Destaque'}
          </h2>
          <Link href="/cities">
            <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 rounded-xl">
              Ver todas →
            </Button>
          </Link>
        </div>
        
        {citiesLoading ? (
          <div className="grid grid-cols-1 gap-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="h-20 bg-muted rounded-lg" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {featuredCities.slice(0, 3).map((city: any) => (
              <Link key={city.id} href={`/cities/${city.slug}`}>
                <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.02] bg-gradient-to-br from-white to-blue-50 border border-blue-100 material-elevation-1">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                          <MapPin className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-900">{city.name}</h3>
                          <p className="text-sm text-gray-600">
                            {city.population ? `${formatPopulation(city.population)} habitantes` : 'Região metropolitana'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="secondary" className="mb-1">
                          {city.state}
                        </Badge>
                        <div className="text-xs text-gray-500">
                          Ver empresas →
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Recent Businesses */}
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-foreground flex items-center">
            <div className="w-1 h-6 bg-gradient-to-b from-accent to-primary rounded-full mr-3"></div>
            {selectedCity ? `Empresas em ${selectedCity.name}` : 'Empresas Recentes'}
          </h2>
          <Link href="/businesses">
            <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 rounded-xl">
              Ver todas →
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 gap-3">
          {recentBusinesses?.map((business: any) => (
            <Card key={business.id} className="cursor-pointer transition-all duration-200 hover:shadow-lg bg-gradient-to-r from-white to-gray-50 border border-gray-200 material-elevation-1">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{business.name}</h3>
                    <p className="text-sm text-gray-600">{business.category} • {business.neighborhood || 'BH Norte'}</p>
                  </div>
                  {business.phone && (
                    <Button size="sm" variant="outline" className="text-primary border-primary hover:bg-primary hover:text-white">
                      <Phone className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )) || (
            <div className="text-center py-8">
              <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Carregando empresas...</p>
            </div>
          )}
        </div>
      </section>

      {/* Quick Transport Access */}
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-foreground flex items-center">
            <div className="w-1 h-6 bg-gradient-to-b from-green-500 to-blue-500 rounded-full mr-3"></div>
            Transporte Público
          </h2>
          <Link href="/lines">
            <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 rounded-xl">
              Ver linhas →
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <Link href="/lines">
            <Button 
              variant="outline"
              className="h-auto p-4 w-full bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 border border-green-200 material-elevation-1 touch-target group transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="w-10 h-10 bg-green-200 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Bus className="w-5 h-5 text-green-700" />
                </div>
                <div className="text-center">
                  <span className="text-sm font-semibold block text-green-900">Linhas de Ônibus</span>
                  <span className="text-xs text-green-700">{busLines?.data?.length || 0} linhas</span>
                </div>
              </div>
            </Button>
          </Link>
          
          <Button 
            variant="outline"
            className="h-auto p-4 w-full bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border border-blue-200 material-elevation-1 touch-target group transition-all duration-300"
            onClick={handleFindNearby}
          >
            <div className="flex flex-col items-center space-y-2">
              <div className="w-10 h-10 bg-blue-200 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <MapPin className="w-5 h-5 text-blue-700" />
              </div>
              <div className="text-center">
                <span className="text-sm font-semibold block text-blue-900">Paradas Próximas</span>
                <span className="text-xs text-blue-700">Localizar</span>
              </div>
            </div>
          </Button>
        </div>
      </section>

      {/* Live Updates - Compact */}
      {liveUpdates?.data && liveUpdates.data.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-foreground flex items-center">
              <div className="w-1 h-5 bg-gradient-to-b from-red-500 to-orange-500 rounded-full mr-3"></div>
              Avisos Importantes
            </h2>
            <div className="flex items-center space-x-2 bg-red-50 px-2 py-1 rounded-full">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-xs text-red-600 font-semibold">ATIVO</span>
            </div>
          </div>
          
          <div className="space-y-2">
            {liveUpdates.data.slice(0, 2).map((update) => (
              <Card key={update.id} className="border-l-4 border-l-red-500 bg-red-50/50">
                <CardContent className="p-3">
                  <div className="flex items-start space-x-2">
                    <Bell className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-red-900 text-sm">{update.title}</h4>
                      <p className="text-xs text-red-700">{update.message}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Bottom padding for navigation */}
      <div className="h-20" />
    </div>
  );
}
