import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  MapPin, 
  Users, 
  Clock, 
  Building2, 
  Phone, 
  MessageCircle, 
  Mail, 
  Globe, 
  MapPin as LocationIcon,
  ArrowLeft,
  ExternalLink
} from "lucide-react";
import { Link } from "wouter";

interface Business {
  id: string;
  name: string;
  slug: string;
  category: string;
  subcategory: string | null;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  neighborhood: string | null;
  postalCode: string | null;
  coordinates: string | null;
  banner: string | null;
  images: string[] | null;
  description: string | null;
  services: string[] | null;
  workingHours: any;
  priceRange: string | null;
  rating: number | null;
  reviewCount: number | null;
  isVerified: boolean;
  isActive: boolean;
}

interface CityWithBusinesses {
  id: string;
  name: string;
  slug: string;
  state: string;
  population: number | null;
  distanceFromBH: number | null;
  description: string | null;
  banner: string | null;
  coordinates: string | null;
  isActive: boolean;
  createdAt: Date;
  businesses: Business[];
  businessCount: number;
  topCategories: string[];
}

export default function CityDetailPage() {
  const [match, params] = useRoute("/cities/:slug");
  const slug = params?.slug;

  const { data: city, isLoading } = useQuery({
    queryKey: ["/api/cities", slug],
    queryFn: async () => {
      const response = await fetch(`/api/cities/${slug}`);
      if (!response.ok) {
        throw new Error("Cidade não encontrada");
      }
      const result = await response.json();
      return result.data as CityWithBusinesses;
    },
    enabled: !!slug,
  });

  const formatPopulation = (population: number | null) => {
    if (!population) return "N/A";
    return new Intl.NumberFormat("pt-BR").format(population);
  };

  const handleWhatsAppClick = (whatsapp: string, companyName: string) => {
    const message = `Olá! Gostaria de mais informações sobre os serviços de transporte da ${companyName}.`;
    const url = `https://wa.me/${whatsapp}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  };

  const handlePhoneClick = (phone: string) => {
    window.open(`tel:${phone}`, "_self");
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
          <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded mb-6"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 dark:bg-gray-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!city) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
          Cidade não encontrada
        </h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4">
          A cidade solicitada não foi encontrada.
        </p>
        <Link href="/cities">
          <Button variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar às cidades
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-6">
        <Link href="/cities">
          <Button variant="ghost" className="mb-4" data-testid="button-back-cities">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar às cidades
          </Button>
        </Link>

        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-6 text-white mb-6">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
                <MapPin className="h-8 w-8" />
                {city.name}
                <Badge variant="secondary" className="text-gray-900">
                  {city.state}
                </Badge>
              </h1>
              <p className="text-blue-100 text-lg mb-4">
                {city.description || "Cidade da região metropolitana"}
              </p>
              
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span>{formatPopulation(city.population)} habitantes</span>
                </div>
                {city.distanceFromBH && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>{city.distanceFromBH} km de BH</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transport Companies */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Building2 className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          Empresas de Transporte
        </h2>
        
        {city.companies.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                Nenhuma empresa cadastrada
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Ainda não há empresas de transporte cadastradas para {city.name}.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {city.companies.map((company) => (
              <Card 
                key={company.id} 
                className="bg-gradient-to-br from-white to-blue-50 dark:from-gray-800 dark:to-gray-900 border border-blue-100 dark:border-blue-800"
                data-testid={`card-company-${company.slug}`}
              >
                <CardHeader>
                  <CardTitle className="text-xl text-gray-900 dark:text-white flex items-start justify-between">
                    <div>
                      {company.name}
                      <div className="text-sm font-normal text-gray-600 dark:text-gray-300 mt-1">
                        {company.neighborhood && `${company.neighborhood} • `}
                        {company.address}
                      </div>
                    </div>
                  </CardTitle>
                  
                  {company.description && (
                    <CardDescription className="text-gray-600 dark:text-gray-300">
                      {company.description}
                    </CardDescription>
                  )}
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Services */}
                  {company.services && company.services.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Serviços</h4>
                      <div className="flex flex-wrap gap-2">
                        {company.services.map((service, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Working Hours */}
                  {company.workingHours && (
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white mb-1">Horário de Funcionamento</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300">{company.workingHours}</p>
                    </div>
                  )}

                  <Separator />

                  {/* Contact Actions */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900 dark:text-white">Contato</h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {company.whatsapp && (
                        <Button
                          onClick={() => handleWhatsAppClick(company.whatsapp!, company.name)}
                          className="bg-green-600 hover:bg-green-700 text-white"
                          size="sm"
                          data-testid={`button-whatsapp-${company.slug}`}
                        >
                          <MessageCircle className="h-4 w-4 mr-2" />
                          WhatsApp
                        </Button>
                      )}

                      {company.phone && (
                        <Button
                          onClick={() => handlePhoneClick(company.phone!)}
                          variant="outline"
                          size="sm"
                          data-testid={`button-phone-${company.slug}`}
                        >
                          <Phone className="h-4 w-4 mr-2" />
                          Ligar
                        </Button>
                      )}

                      {company.email && (
                        <Button
                          onClick={() => window.open(`mailto:${company.email}`, "_self")}
                          variant="outline"
                          size="sm"
                          data-testid={`button-email-${company.slug}`}
                        >
                          <Mail className="h-4 w-4 mr-2" />
                          E-mail
                        </Button>
                      )}

                      {company.website && (
                        <Button
                          onClick={() => window.open(company.website!, "_blank")}
                          variant="outline"
                          size="sm"
                          data-testid={`button-website-${company.slug}`}
                        >
                          <Globe className="h-4 w-4 mr-2" />
                          Site
                          <ExternalLink className="h-3 w-3 ml-1" />
                        </Button>
                      )}
                    </div>

                    {/* Address with postal code */}
                    {(company.address || company.postalCode) && (
                      <div className="pt-2 border-t border-gray-100 dark:border-gray-700">
                        <div className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-300">
                          <LocationIcon className="h-4 w-4 mt-0.5 flex-shrink-0" />
                          <div>
                            {company.address}
                            {company.neighborhood && `, ${company.neighborhood}`}
                            {company.postalCode && (
                              <div className="font-mono">{company.postalCode}</div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}