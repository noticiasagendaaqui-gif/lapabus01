import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Navigation, Layers, Camera } from "lucide-react";
import { TouristAttractions } from "@/components/maps/tourist-attractions";

export default function Map() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <h1 className="text-2xl font-bold text-foreground">Mapa e Turismo</h1>
        <p className="text-sm text-muted-foreground">
          Explore rotas de ônibus e pontos turísticos da região
        </p>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="map" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="map" data-testid="tab-map">Mapa</TabsTrigger>
          <TabsTrigger value="tourism" data-testid="tab-tourism">Turismo</TabsTrigger>
        </TabsList>
        
        <TabsContent value="map" className="space-y-6 mt-6">
          {/* Map Placeholder */}
          <Card className="aspect-[4/3] relative overflow-hidden">
            <CardContent className="h-full p-0">
              <div className="h-full bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 flex items-center justify-center">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
                    <MapPin className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Mapa Interativo</h3>
                    <p className="text-sm text-muted-foreground">Integrado com OpenStreetMap</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Map Controls */}
          <div className="grid grid-cols-3 gap-3">
            <Button 
              variant="outline" 
              className="h-auto p-4 material-elevation-1 touch-target"
              data-testid="button-my-location"
              onClick={() => {
                if (navigator.geolocation) {
                  navigator.geolocation.getCurrentPosition(
                    (position) => {
                      const { latitude, longitude } = position.coords;
                      const mapUrl = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}&zoom=15`;
                      window.open(mapUrl, '_blank');
                    },
                    (error) => {
                      console.error('Erro ao obter localização:', error);
                      // Fallback para centro de BH Norte
                      const mapUrl = `https://www.openstreetmap.org/?mlat=-19.6920&mlon=-44.0080&zoom=12`;
                      window.open(mapUrl, '_blank');
                    }
                  );
                } else {
                  const mapUrl = `https://www.openstreetmap.org/?mlat=-19.6920&mlon=-44.0080&zoom=12`;
                  window.open(mapUrl, '_blank');
                }
              }}
            >
              <div className="flex flex-col items-center space-y-2">
                <Navigation className="w-6 h-6" />
                <span className="text-sm font-medium">Localização</span>
              </div>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-4 material-elevation-1 touch-target"
              data-testid="button-layers"
              onClick={() => {
                const mapUrl = `https://www.openstreetmap.org/?mlat=-19.6920&mlon=-44.0080&zoom=11`;
                window.open(mapUrl, '_blank');
              }}
            >
              <div className="flex flex-col items-center space-y-2">
                <Layers className="w-6 h-6" />
                <span className="text-sm font-medium">Região</span>
              </div>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-4 material-elevation-1 touch-target"
              data-testid="button-satellite"
              onClick={() => {
                window.open('https://www.openstreetmap.org/#map=11/-19.6920/-44.0080&layers=G', '_blank');
              }}
            >
              <div className="flex flex-col items-center space-y-2">
                <Camera className="w-6 h-6" />
                <span className="text-sm font-medium">Satélite</span>
              </div>
            </Button>
          </div>

          {/* Quick Info */}
          <Card className="material-elevation-1">
            <CardContent className="p-4 space-y-4">
              <h3 className="font-semibold text-foreground">Recursos do Mapa</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <span>Rotas das linhas de ônibus</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-secondary rounded-full" />
                  <span>Paradas e terminais</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-accent rounded-full" />
                  <span>Pontos turísticos</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>GPS em tempo real</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="tourism" className="mt-6">
          <TouristAttractions />
        </TabsContent>
      </Tabs>

      {/* Bottom padding for navigation */}
      <div className="h-20" />
    </div>
  );
}
