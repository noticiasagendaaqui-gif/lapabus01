import { useState } from "react";

interface GeolocationPosition {
  latitude: number;
  longitude: number;
  accuracy: number;
}

interface GeolocationError {
  code: number;
  message: string;
}

export function useGeolocation() {
  const [position, setPosition] = useState<GeolocationPosition | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<GeolocationError | null>(null);

  const getCurrentPosition = (): Promise<GeolocationPosition> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        const error = { code: 0, message: "Geolocation is not supported" };
        setError(error);
        reject(error);
        return;
      }

      setLoading(true);
      setError(null);

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const position = {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
          };
          setPosition(position);
          setLoading(false);
          resolve(position);
        },
        (err) => {
          const error = {
            code: err.code,
            message: getErrorMessage(err.code),
          };
          setError(error);
          setLoading(false);
          reject(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000, // 5 minutes
        }
      );
    });
  };

  const watchPosition = (callback: (position: GeolocationPosition) => void): number | null => {
    if (!navigator.geolocation) {
      setError({ code: 0, message: "Geolocation is not supported" });
      return null;
    }

    return navigator.geolocation.watchPosition(
      (pos) => {
        const position = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };
        setPosition(position);
        callback(position);
      },
      (err) => {
        setError({
          code: err.code,
          message: getErrorMessage(err.code),
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000,
      }
    );
  };

  const clearWatch = (watchId: number) => {
    navigator.geolocation.clearWatch(watchId);
  };

  return {
    position,
    loading,
    error,
    getCurrentPosition,
    watchPosition,
    clearWatch,
  };
}

function getErrorMessage(code: number): string {
  switch (code) {
    case 1:
      return "Acesso à localização negado pelo usuário";
    case 2:
      return "Posição indisponível";
    case 3:
      return "Timeout ao obter localização";
    default:
      return "Erro desconhecido ao obter localização";
  }
}
