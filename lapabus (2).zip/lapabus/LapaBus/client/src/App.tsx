import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppShell } from "@/components/layout/app-shell";
import { InstallPrompt } from "@/components/pwa/install-prompt";
import { LocationProvider } from "@/contexts/LocationContext";
import Home from "@/pages/home";
import Lines from "@/pages/lines";
import Map from "@/pages/map";
import Settings from "@/pages/settings";
import Cities from "@/pages/cities";
import CityDetail from "@/pages/city-detail";
import Businesses from "@/pages/businesses";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/lines" component={Lines} />
      <Route path="/map" component={Map} />
      <Route path="/cities" component={Cities} />
      <Route path="/cities/:slug" component={CityDetail} />
      <Route path="/businesses" component={Businesses} />
      <Route path="/businesses/:category" component={Businesses} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LocationProvider>
        <TooltipProvider>
          <AppShell>
            <Router />
          </AppShell>
          <InstallPrompt />
          <Toaster />
        </TooltipProvider>
      </LocationProvider>
    </QueryClientProvider>
  );
}

export default App;
