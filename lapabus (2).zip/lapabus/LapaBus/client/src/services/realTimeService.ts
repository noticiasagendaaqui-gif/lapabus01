// Service for integrating with real bus APIs
export interface RealTimeSchedule {
  line: string;
  direction?: string;
  schedules: string[];
  type: 'weekday' | 'saturday' | 'sunday' | 'holiday';
  source: string;
}

export interface RealTimeBusPosition {
  vehicleId: string;
  lineCode: string;
  latitude: number;
  longitude: number;
  timestamp: string;
  speed?: number;
  direction?: number;
}

export interface RouteInfo {
  itinerary?: any;
  fare?: any;
  source: string;
}

class RealTimeService {
  private baseUrl = '/api/external';

  async getSchedule(lineNumber: string, type: 'weekday' | 'saturday' | 'sunday' | 'holiday'): Promise<RealTimeSchedule | null> {
    try {
      const response = await fetch(`${this.baseUrl}/schedule/${lineNumber}/${type}`);
      
      if (!response.ok) {
        console.warn(`Failed to fetch real schedule for line ${lineNumber}: ${response.status}`);
        return null;
      }
      
      const result = await response.json();
      
      if (result.success) {
        return {
          line: lineNumber,
          schedules: this.parseScheduleData(result.data),
          type,
          source: result.source
        };
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching real schedule:', error);
      return null;
    }
  }

  async getBusPositions(): Promise<RealTimeBusPosition[]> {
    try {
      const response = await fetch(`${this.baseUrl}/realtime-positions`);
      
      if (!response.ok) {
        console.warn('Failed to fetch real-time positions');
        return [];
      }
      
      const result = await response.json();
      
      if (result.success && result.data) {
        return this.parsePositionData(result.data);
      }
      
      return [];
    } catch (error) {
      console.error('Error fetching bus positions:', error);
      return [];
    }
  }

  async getRouteInfo(lineNumber: string): Promise<RouteInfo | null> {
    try {
      const response = await fetch(`${this.baseUrl}/route/${lineNumber}`);
      
      if (!response.ok) {
        console.warn(`Failed to fetch route info for line ${lineNumber}`);
        return null;
      }
      
      const result = await response.json();
      
      if (result.success) {
        return result.data;
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching route info:', error);
      return null;
    }
  }

  // Parse OpenBHBus schedule data format
  private parseScheduleData(data: any): string[] {
    if (!data || !Array.isArray(data)) {
      return [];
    }

    // Extract schedule times from the API response
    // The exact format depends on OpenBHBus API structure
    const schedules: string[] = [];
    
    data.forEach((item: any) => {
      if (item.horario || item.time || item.hora) {
        const time = item.horario || item.time || item.hora;
        if (typeof time === 'string') {
          schedules.push(time);
        }
      }
    });

    return schedules.sort();
  }

  // Parse BHTrans real-time position data
  private parsePositionData(data: any): RealTimeBusPosition[] {
    if (!data || !Array.isArray(data)) {
      return [];
    }

    return data.map((item: any) => ({
      vehicleId: item.VEICULO || item.vehicle || item.id || 'unknown',
      lineCode: item.EV || item.line || item.linha || 'unknown',
      latitude: parseFloat(item.LAT || item.latitude || 0),
      longitude: parseFloat(item.LON || item.longitude || 0),
      timestamp: item.TIMESTAMP || item.timestamp || new Date().toISOString(),
      speed: item.VELOCIDADE || item.speed || undefined,
      direction: item.DIRECAO || item.direction || undefined
    })).filter(pos => pos.latitude !== 0 && pos.longitude !== 0);
  }

  // Check if real-time data is available for enhanced features
  async isRealTimeAvailable(): Promise<boolean> {
    try {
      const [positionsResponse] = await Promise.all([
        fetch(`${this.baseUrl}/realtime-positions`, { method: 'HEAD' })
      ]);
      
      return positionsResponse.ok;
    } catch {
      return false;
    }
  }

  // Get current day schedule type
  getCurrentScheduleType(): 'weekday' | 'saturday' | 'sunday' | 'holiday' {
    const now = new Date();
    const day = now.getDay(); // 0 = Sunday, 6 = Saturday
    
    // Check for holidays (simplified - in real app, check against holiday calendar)
    const isHoliday = this.isHoliday(now);
    
    if (isHoliday) return 'holiday';
    if (day === 0) return 'sunday';
    if (day === 6) return 'saturday';
    return 'weekday';
  }

  // Simple holiday check (should be expanded with real holiday calendar)
  private isHoliday(date: Date): boolean {
    const month = date.getMonth() + 1;
    const day = date.getDate();
    
    // Common Brazilian holidays (simplified)
    const holidays = [
      [1, 1],   // New Year
      [4, 21],  // Tiradentes
      [9, 7],   // Independence Day
      [10, 12], // Our Lady of Aparecida
      [11, 2],  // All Souls' Day
      [11, 15], // Proclamation of the Republic
      [12, 25]  // Christmas
    ];
    
    return holidays.some(([hMonth, hDay]) => month === hMonth && day === hDay);
  }
}

export const realTimeService = new RealTimeService();